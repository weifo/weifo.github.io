Before submitting an issue, please search for the issue [here](https://github.com/iissnan/hexo-theme-next/issues?utf8=%E2%9C%93&q=) to find if the issue is already reported.

Also, you can search for answers on the [NexT Documentation Site](http://theme-next.iissnan.com/):

- [常见问题 - 中文文档](http://theme-next.iissnan.com/faqs.html)
- FAQs (Work in progress)
